package com.example.oreESP;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class OreESPClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Register keybind (G = buka menu)
        ESPKeyBinding.register();

        // Register world renderer (box + trace 3D)
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ESPRenderer::render);

        // Register HUD (crosshair tracker + label)
        ESPHud.register();
    }
}
