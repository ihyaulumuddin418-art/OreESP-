package com.example.oreESP;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

public class ESPRenderer {

    private static final Set<Block> ORE_BLOCKS = new HashSet<>();

    static {
        ORE_BLOCKS.add(Blocks.DIAMOND_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        ORE_BLOCKS.add(Blocks.EMERALD_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_EMERALD_ORE);
        ORE_BLOCKS.add(Blocks.GOLD_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_GOLD_ORE);
        ORE_BLOCKS.add(Blocks.IRON_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_IRON_ORE);
        ORE_BLOCKS.add(Blocks.COAL_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_COAL_ORE);
        ORE_BLOCKS.add(Blocks.LAPIS_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_LAPIS_ORE);
        ORE_BLOCKS.add(Blocks.REDSTONE_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_REDSTONE_ORE);
        ORE_BLOCKS.add(Blocks.COPPER_ORE);
        ORE_BLOCKS.add(Blocks.DEEPSLATE_COPPER_ORE);
        ORE_BLOCKS.add(Blocks.ANCIENT_DEBRIS);
        ORE_BLOCKS.add(Blocks.NETHER_GOLD_ORE);
        ORE_BLOCKS.add(Blocks.NETHER_QUARTZ_ORE);
    }

    public static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (!ESPConfig.blockEntityESP && !ESPConfig.oreESP && !ESPConfig.spawnerESP) return;

        World world = client.world;
        BlockPos playerPos = client.player.getBlockPos();
        Vec3d camPos = context.camera().getPos();

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);

        VertexConsumer lines = consumers.getBuffer(RenderLayer.LINES);

        // === Block Entity ESP (radius 150, warna biru muda) ===
        if (ESPConfig.blockEntityESP) {
            for (BlockEntity be : world.blockEntities) {
                BlockPos pos = be.getPos();
                // skip spawner, handled separately
                if (be.getType() == BlockEntityType.MOB_SPAWNER) continue;
                if (playerPos.getSquaredDistance(pos) <= 150.0 * 150.0) {
                    drawBox(matrices, lines, pos, 0.0f, 0.8f, 1.0f, 1.0f);
                    drawTrace(matrices, lines, camPos, pos, 0.0f, 0.8f, 1.0f);
                }
            }
        }

        // === Spawner ESP (radius 200, warna ungu) ===
        if (ESPConfig.spawnerESP) {
            for (BlockEntity be : world.blockEntities) {
                BlockPos pos = be.getPos();
                if (be.getType() == BlockEntityType.MOB_SPAWNER) {
                    if (playerPos.getSquaredDistance(pos) <= 200.0 * 200.0) {
                        drawBox(matrices, lines, pos, 1.0f, 0.0f, 1.0f, 1.0f);
                        drawTrace(matrices, lines, camPos, pos, 1.0f, 0.0f, 1.0f);
                    }
                }
            }
        }

        // === Ore ESP (radius 25, warna per jenis ore) ===
        if (ESPConfig.oreESP) {
            for (BlockPos pos : BlockPos.iterate(
                playerPos.add(-25, -25, -25),
                playerPos.add(25, 25, 25)
            )) {
                if (playerPos.getSquaredDistance(pos) > 25.0 * 25.0) continue;
                Block block = world.getBlockState(pos).getBlock();
                if (ORE_BLOCKS.contains(block)) {
                    float[] c = getOreColor(block);
                    BlockPos immutable = pos.toImmutable();
                    drawBox(matrices, lines, immutable, c[0], c[1], c[2], 1.0f);
                    drawTrace(matrices, lines, camPos, immutable, c[0], c[1], c[2]);
                }
            }
        }

        matrices.pop();
    }

    private static float[] getOreColor(Block block) {
        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE)
            return new float[]{0.0f, 1.0f, 1.0f}; // Cyan
        if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE)
            return new float[]{0.0f, 1.0f, 0.0f}; // Hijau
        if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE)
            return new float[]{1.0f, 1.0f, 0.0f}; // Kuning
        if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE)
            return new float[]{0.9f, 0.7f, 0.5f}; // Coklat muda
        if (block == Blocks.ANCIENT_DEBRIS)
            return new float[]{1.0f, 0.3f, 0.0f}; // Oranye
        if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE)
            return new float[]{0.0f, 0.2f, 1.0f}; // Biru tua
        if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE)
            return new float[]{1.0f, 0.0f, 0.0f}; // Merah
        if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE)
            return new float[]{0.9f, 0.4f, 0.1f}; // Tembaga
        if (block == Blocks.NETHER_QUARTZ_ORE)
            return new float[]{1.0f, 1.0f, 1.0f}; // Putih
        return new float[]{0.5f, 0.5f, 0.5f};
    }

    // Gambar outline box 1x1x1 di posisi block
    private static void drawBox(MatrixStack matrices, VertexConsumer consumer,
                                 BlockPos pos, float r, float g, float b, float a) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        float x  = pos.getX();
        float y  = pos.getY();
        float z  = pos.getZ();
        float x2 = x + 1f, y2 = y + 1f, z2 = z + 1f;

        // Bottom face
        line(consumer, m, x,  y,  z,  x2, y,  z,  r, g, b, a);
        line(consumer, m, x2, y,  z,  x2, y,  z2, r, g, b, a);
        line(consumer, m, x2, y,  z2, x,  y,  z2, r, g, b, a);
        line(consumer, m, x,  y,  z2, x,  y,  z,  r, g, b, a);
        // Top face
        line(consumer, m, x,  y2, z,  x2, y2, z,  r, g, b, a);
        line(consumer, m, x2, y2, z,  x2, y2, z2, r, g, b, a);
        line(consumer, m, x2, y2, z2, x,  y2, z2, r, g, b, a);
        line(consumer, m, x,  y2, z2, x,  y2, z,  r, g, b, a);
        // Vertical edges
        line(consumer, m, x,  y,  z,  x,  y2, z,  r, g, b, a);
        line(consumer, m, x2, y,  z,  x2, y2, z,  r, g, b, a);
        line(consumer, m, x2, y,  z2, x2, y2, z2, r, g, b, a);
        line(consumer, m, x,  y,  z2, x,  y2, z2, r, g, b, a);
    }

    // Gambar garis trace dari kamera ke tengah block
    private static void drawTrace(MatrixStack matrices, VertexConsumer consumer,
                                   Vec3d camPos, BlockPos pos, float r, float g, float b) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        // Dari titik kamera (0,0,0 setelah translate)
        float cx = (float)(camPos.x - camPos.x); // = 0
        float cy = (float)(camPos.y - camPos.y); // = 0
        float cz = (float)(camPos.z - camPos.z); // = 0
        // Ke tengah block
        float tx = pos.getX() + 0.5f;
        float ty = pos.getY() + 0.5f;
        float tz = pos.getZ() + 0.5f;

        line(consumer, m, 0f, 0f, 0f, tx, ty, tz, r, g, b, 0.6f);
    }

    private static void line(VertexConsumer c, Matrix4f m,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a) {
        // Normal direction
        float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        float len = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (len == 0) len = 1;
        c.vertex(m, x1, y1, z1).color(r, g, b, a).normal(dx/len, dy/len, dz/len).next();
        c.vertex(m, x2, y2, z2).color(r, g, b, a).normal(dx/len, dy/len, dz/len).next();
    }
}
