package com.example.oreESP;

public class ESPConfig {
    public static boolean blockEntityESP = false; // radius 150
    public static boolean oreESP = false;          // radius 25
    public static boolean spawnerESP = false;      // radius 200
}
