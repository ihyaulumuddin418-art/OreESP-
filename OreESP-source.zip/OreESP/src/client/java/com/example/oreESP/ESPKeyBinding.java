package com.example.oreESP;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ESPKeyBinding {

    public static void register() {
        KeyBinding openUI = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.oreESP.openUI",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            "OreESP"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openUI.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new ESPScreen());
                }
            }
        });
    }
}
