package com.example.oreESP;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

public class ESPHud {

    public static void register() {
        HudRenderCallback.EVENT.register(ESPHud::render);
    }

    private static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (!ESPConfig.blockEntityESP && !ESPConfig.oreESP && !ESPConfig.spawnerESP) return;

        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        int cx = screenW / 2;
        int cy = screenH / 2;

        World world = client.world;
        BlockPos playerPos = client.player.getBlockPos();
        Vec3d eyePos = client.player.getEyePos();
        Vec3d lookVec = client.player.getRotationVec(tickCounter.getTickDelta(false));

        // Cari target terdekat yang dilihat (paling dekat dengan look direction)
        BlockPos bestPos = null;
        float bestDot = -1f;
        int bestColor = 0xFFFFFF;

        // Block entities
        if (ESPConfig.blockEntityESP) {
            for (BlockEntity be : world.blockEntities) {
                BlockPos pos = be.getPos();
                if (be.getType() == BlockEntityType.MOB_SPAWNER) continue;
                if (playerPos.getSquaredDistance(pos) > 150.0 * 150.0) continue;
                float dot = getDot(eyePos, lookVec, pos);
                if (dot > bestDot) { bestDot = dot; bestPos = pos; bestColor = 0x00CCFF; }
            }
        }

        if (ESPConfig.spawnerESP) {
            for (BlockEntity be : world.blockEntities) {
                BlockPos pos = be.getPos();
                if (be.getType() != BlockEntityType.MOB_SPAWNER) continue;
                if (playerPos.getSquaredDistance(pos) > 200.0 * 200.0) continue;
                float dot = getDot(eyePos, lookVec, pos);
                if (dot > bestDot) { bestDot = dot; bestPos = pos; bestColor = 0xFF00FF; }
            }
        }

        if (ESPConfig.oreESP) {
            for (BlockPos pos : BlockPos.iterate(
                playerPos.add(-25, -25, -25),
                playerPos.add(25, 25, 25)
            )) {
                if (playerPos.getSquaredDistance(pos) > 25.0 * 25.0) continue;
                Block block = world.getBlockState(pos).getBlock();
                if (!isOre(block)) continue;
                float dot = getDot(eyePos, lookVec, pos);
                if (dot > bestDot) {
                    bestDot = dot;
                    bestPos = pos.toImmutable();
                    bestColor = getOreHudColor(block);
                }
            }
        }

        // Gambar crosshair tracker ke target terdekat di layar
        if (bestPos != null && bestDot > 0.3f) {
            // Hitung arah ke target di layar 2D
            Vec3d toTarget = new Vec3d(
                bestPos.getX() + 0.5 - eyePos.x,
                bestPos.getY() + 0.5 - eyePos.y,
                bestPos.getZ() + 0.5 - eyePos.z
            ).normalize();

            // Dot product dengan right/up vector
            Vec3d camRight = lookVec.crossProduct(new Vec3d(0, 1, 0)).normalize();
            Vec3d camUp = camRight.crossProduct(lookVec).normalize();

            double dotRight = toTarget.dotProduct(camRight);
            double dotUp = toTarget.dotProduct(camUp);

            // Panjang panah maksimal
            int arrowLen = 30;
            double mag = Math.sqrt(dotRight * dotRight + dotUp * dotUp);
            if (mag > 0) {
                int ax = (int)(cx + (dotRight / mag) * arrowLen);
                int ay = (int)(cy - (dotUp / mag) * arrowLen);

                // Gambar garis dari tengah layar ke arah target
                drawLine2D(context, cx, cy, ax, ay, bestColor);

                // Titik di ujung
                context.fill(ax - 2, ay - 2, ax + 2, ay + 2, 0xFF000000 | bestColor);
            }
        }

        // Label ON di pojok kiri atas
        int y = 5;
        if (ESPConfig.blockEntityESP) {
            context.drawTextWithShadow(client.textRenderer, "§b[Block Entity ESP] §aON", 5, y, 0xFFFFFF);
            y += 12;
        }
        if (ESPConfig.oreESP) {
            context.drawTextWithShadow(client.textRenderer, "§6[Ore ESP] §aON", 5, y, 0xFFFFFF);
            y += 12;
        }
        if (ESPConfig.spawnerESP) {
            context.drawTextWithShadow(client.textRenderer, "§d[Spawner ESP] §aON", 5, y, 0xFFFFFF);
        }
    }

    private static float getDot(Vec3d eye, Vec3d look, BlockPos pos) {
        Vec3d dir = new Vec3d(
            pos.getX() + 0.5 - eye.x,
            pos.getY() + 0.5 - eye.y,
            pos.getZ() + 0.5 - eye.z
        ).normalize();
        return (float) look.dotProduct(dir);
    }

    private static void drawLine2D(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        int argb = 0xFF000000 | color;
        int dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1);
        int steps = Math.max(dx, dy);
        if (steps == 0) return;
        for (int i = 0; i <= steps; i++) {
            int x = x1 + (x2 - x1) * i / steps;
            int y = y1 + (y2 - y1) * i / steps;
            ctx.fill(x, y, x + 1, y + 1, argb);
        }
    }

    private static boolean isOre(Block block) {
        return block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE
            || block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE
            || block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE
            || block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE
            || block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE
            || block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE
            || block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE
            || block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE
            || block == Blocks.ANCIENT_DEBRIS || block == Blocks.NETHER_GOLD_ORE
            || block == Blocks.NETHER_QUARTZ_ORE;
    }

    private static int getOreHudColor(Block block) {
        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) return 0x00FFFF;
        if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) return 0x00FF00;
        if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE) return 0xFFFF00;
        if (block == Blocks.ANCIENT_DEBRIS) return 0xFF4400;
        if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) return 0x0033FF;
        if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) return 0xFF0000;
        if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) return 0xFF6600;
        return 0xFFFFFF;
    }
}
