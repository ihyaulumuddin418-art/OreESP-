package com.example.oreESP;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ESPScreen extends Screen {

    public ESPScreen() {
        super(Text.literal("OreESP Settings"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int sy = this.height / 2 - 70;

        // Block Entity ESP
        this.addDrawableChild(ButtonWidget.builder(
            getLabel("§b[Block Entity ESP]§r", ESPConfig.blockEntityESP),
            btn -> {
                ESPConfig.blockEntityESP = !ESPConfig.blockEntityESP;
                btn.setMessage(getLabel("§b[Block Entity ESP]§r", ESPConfig.blockEntityESP));
            }
        ).dimensions(cx - 110, sy, 220, 24).build());

        // Ore ESP
        this.addDrawableChild(ButtonWidget.builder(
            getLabel("§6[Ore ESP]§r", ESPConfig.oreESP),
            btn -> {
                ESPConfig.oreESP = !ESPConfig.oreESP;
                btn.setMessage(getLabel("§6[Ore ESP]§r", ESPConfig.oreESP));
            }
        ).dimensions(cx - 110, sy + 32, 220, 24).build());

        // Spawner ESP
        this.addDrawableChild(ButtonWidget.builder(
            getLabel("§d[Spawner ESP]§r", ESPConfig.spawnerESP),
            btn -> {
                ESPConfig.spawnerESP = !ESPConfig.spawnerESP;
                btn.setMessage(getLabel("§d[Spawner ESP]§r", ESPConfig.spawnerESP));
            }
        ).dimensions(cx - 110, sy + 64, 220, 24).build());

        // Close
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Close"),
            btn -> this.close()
        ).dimensions(cx - 40, sy + 108, 80, 24).build());
    }

    private Text getLabel(String name, boolean state) {
        return Text.literal(name + " " + (state ? "§aON" : "§cOFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(
            this.textRenderer,
            "§e§lOreESP Settings",
            this.width / 2,
            this.height / 2 - 100,
            0xFFFFFF
        );
        context.drawCenteredTextWithShadow(
            this.textRenderer,
            "§7Press G to open/close",
            this.width / 2,
            this.height / 2 - 88,
            0xAAAAAA
        );
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
